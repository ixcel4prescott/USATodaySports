package com.jetbrains.python.psi;

/**
 * Generator expression PSI.
 *
 * @author yole
 */
public interface PyGeneratorExpression extends PyComprehensionElement {
}
