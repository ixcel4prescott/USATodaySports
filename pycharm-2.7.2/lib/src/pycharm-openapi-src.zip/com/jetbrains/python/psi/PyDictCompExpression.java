package com.jetbrains.python.psi;

/**
 * Dict comprehension: {x:x+1 for x in range(10)}
 * 
 * @author yole
 */
public interface PyDictCompExpression extends PyComprehensionElement {
}
