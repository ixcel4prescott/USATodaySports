package com.jetbrains.python.psi;

/**
 * @author yole
 */
public interface PyPrintTarget extends PyElement {
}
