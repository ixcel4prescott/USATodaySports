package com.jetbrains.python.psi;

/**
 * @author yole
 */
public interface PyTupleExpression extends PySequenceExpression, Iterable<PyExpression> {
}
