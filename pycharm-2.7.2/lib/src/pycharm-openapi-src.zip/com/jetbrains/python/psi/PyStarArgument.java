package com.jetbrains.python.psi;

/**
 * @author yole
 */
public interface PyStarArgument extends PyExpression {
  boolean isKeyword();
}
