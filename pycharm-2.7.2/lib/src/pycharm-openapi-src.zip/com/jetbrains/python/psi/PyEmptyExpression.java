package com.jetbrains.python.psi;

/**
 * @author yole
 */
public interface PyEmptyExpression extends PyExpression {
}
