package com.jetbrains.python.psi;

/**
 * List comprehension PSI.
 *
 * @author yole
 */
public interface PyListCompExpression extends PyComprehensionElement {
}
