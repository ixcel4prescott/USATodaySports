package com.jetbrains.python.psi;

/**
 * @author yole
 */
public interface PyListLiteralExpression extends PySequenceExpression {
}
