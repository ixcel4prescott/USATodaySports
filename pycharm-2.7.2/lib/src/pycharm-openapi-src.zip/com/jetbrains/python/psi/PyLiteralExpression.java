package com.jetbrains.python.psi;

/**
 * @author yole
 */
public interface PyLiteralExpression extends PyExpression {
}
