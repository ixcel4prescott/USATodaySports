package com.jetbrains.python.psi;


public interface PyExpressionCodeFragment extends PyFile {
}
