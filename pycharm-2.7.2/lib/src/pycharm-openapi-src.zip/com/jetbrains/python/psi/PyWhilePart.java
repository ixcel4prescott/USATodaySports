package com.jetbrains.python.psi;

/**
 * The 'while' part of a cycle.
 * @see PyElsePart
 *
 * @author dcheryasov
 */
public interface PyWhilePart extends PyConditionalStatementPart {
}
