package com.jetbrains.python.psi;

/**
 * @author yole
 */
public interface PyWithStatement extends PyStatement, NameDefiner {
  PyWithItem[] getWithItems();
}
