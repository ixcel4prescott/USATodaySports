package com.jetbrains.python.psi;

/**
 * Set comprehension: {x for x in range(10)}
 * 
 * @author yole
 */
public interface PySetCompExpression extends PyComprehensionElement {
}
