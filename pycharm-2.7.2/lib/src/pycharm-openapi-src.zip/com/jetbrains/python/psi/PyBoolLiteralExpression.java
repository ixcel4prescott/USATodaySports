package com.jetbrains.python.psi;

/**
 * @author yole
 */
public interface PyBoolLiteralExpression extends PyLiteralExpression {
  boolean getValue();
}
