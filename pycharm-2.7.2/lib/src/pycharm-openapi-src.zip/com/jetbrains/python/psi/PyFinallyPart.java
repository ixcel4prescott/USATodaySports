package com.jetbrains.python.psi;

/**
 * The 'finally' part.
 * @see PyTryPart
 * User: dcheryasov
 * Date: Mar 16, 2009 6:29:22 AM
 */
public interface PyFinallyPart extends PyStatementPart {
}
